import 'package:flutter/material.dart';
import 'package:hospital_app/features/presentation/screens/main_part/appoinments_screen.dart';
import 'package:hospital_app/features/presentation/screens/main_part/dashboard_screen.dart';
import 'package:hospital_app/features/presentation/screens/main_part/doctors_screen.dart';
import 'package:hospital_app/features/presentation/screens/main_part/patients_screen.dart';
import 'package:hospital_app/features/presentation/screens/register_part/login_screen.dart';
import 'package:hospital_app/features/presentation/screens/register_part/register_screen.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/login',
      routes: {
        '/register': (context) => const RegisterScreen(),
        '/login': (context) => const LoginScreen(),
        '/dashboard': (context) => const DashboardScreen(),
        '/patients': (context) => const PatientsScreen(),
        '/doctors': (context) => const DoctorsScreen(),
        '/appointments': (context) => const AppointmentsScreen(),
      },
    );
  }
}