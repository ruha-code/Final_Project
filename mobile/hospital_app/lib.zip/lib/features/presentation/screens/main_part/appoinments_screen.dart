import 'package:flutter/material.dart';
import 'package:hospital_app/features/presentation/screens/main_part/widgets/app_constant.dart';
import 'package:hospital_app/features/presentation/screens/main_part/widgets/appointment_card.dart';
import 'package:hospital_app/features/presentation/screens/main_part/widgets/bottom_nav_bar.dart';
import 'package:hospital_app/features/presentation/screens/main_part/widgets/filter_tabs.dart';
import 'package:hospital_app/features/presentation/screens/main_part/widgets/section_header.dart';
import 'package:hospital_app/features/presentation/screens/main_part/widgets/stat_card.dart';
import 'package:hospital_app/features/presentation/screens/main_part/widgets/top_nav_bar.dart';

class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});

  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  int _selectedFilter = 0;
  int _selectedNavIndex = 1;

  final _filters = ['All', 'Completed', 'Ongoing', 'Cancelled'];

  final _appointments = const [
    _AppointmentData(
      name: 'Erica Smith',
      phone: '7 777 123 4567',
      initials: 'ES',
      avatarColor: AppColors.primary,
      status: 'Completed',
      statusColor: AppColors.primary,
      doctor: 'Dr. Ning',
      type: 'Consultation',
      date: '12 March',
    ),
    _AppointmentData(
      name: 'John Doe',
      phone: '7 701 558 8998',
      initials: 'JD',
      avatarColor: AppColors.primary,
      status: 'Ongoing',
      statusColor: AppColors.orange,
      doctor: 'Dr. Alex',
      type: 'Follow-up',
      date: '13 March',
    ),
    _AppointmentData(
      name: 'Petya Smith',
      phone: '7 702 334 5566',
      initials: 'PS',
      avatarColor: AppColors.accent,
      status: 'Cancelled',
      statusColor: AppColors.red,
      doctor: 'Dr. Amelia',
      type: 'Check-up',
      date: '14 March',
    ),
    _AppointmentData(
      name: 'Anna Lee',
      phone: '7 707 112 2233',
      initials: 'AL',
      avatarColor: AppColors.pink,
      status: 'Completed',
      statusColor: AppColors.primary,
      doctor: 'Dr. Daniel',
      type: 'Consultation',
      date: '14 March',
    ),
  ];

  List<_AppointmentData> get _filtered {
    if (_selectedFilter == 0) return _appointments;
    return _appointments
        .where((a) => a.status == _filters[_selectedFilter])
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              const TopNavBar(),
              const SizedBox(height: 24),
              const SectionHeader(
                title: 'Appointments',
                subtitle: 'Manage all appointments',
              ),
              const SizedBox(height: 20),
              _buildStatsRow(),
              const SizedBox(height: 24),
              FilterTabs(
                labels: _filters,
                selectedIndex: _selectedFilter,
                onTap: (i) => setState(() => _selectedFilter = i),
              ),
              const SizedBox(height: 16),
              ..._filtered.map((a) => AppointmentCard(
                    name: a.name,
                    phone: a.phone,
                    initials: a.initials,
                    avatarColor: a.avatarColor,
                    status: a.status,
                    statusColor: a.statusColor,
                    doctor: a.doctor,
                    type: a.type,
                    date: a.date,
                  )),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavBar(
        selectedIndex: _selectedNavIndex,
        onTap: (i) => setState(() => _selectedNavIndex = i),
      ),
    );
  }

  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: IconStatCard(
            value: '52',
            label: 'Total',
            change: '4%',
            icon: Icons.bar_chart_rounded,
            iconBgColor: const Color(0xFFEDE9FE),
            iconColor: AppColors.accent,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: IconStatCard(
            value: '28',
            label: 'Completed',
            change: '12',
            icon: Icons.check_circle_rounded,
            iconBgColor: const Color(0xFFE8F5E9),
            iconColor: AppColors.primary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: IconStatCard(
            value: '18',
            label: 'Ongoing',
            change: '0',
            icon: Icons.access_time_rounded,
            iconBgColor: const Color(0xFFFFF3E0),
            iconColor: AppColors.orange,
            isSelected: true,
          ),
        ),
        const SizedBox(width: 12),
        const Text(
          '6',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.black26,
          ),
        ),
      ],
    );
  }
}

// ──────────── data class ────────────

class _AppointmentData {
  final String name;
  final String phone;
  final String initials;
  final Color avatarColor;
  final String status;
  final Color statusColor;
  final String doctor;
  final String type;
  final String date;

  const _AppointmentData({
    required this.name,
    required this.phone,
    required this.initials,
    required this.avatarColor,
    required this.status,
    required this.statusColor,
    required this.doctor,
    required this.type,
    required this.date,
  });
}